﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    class Class1
    {
        //public static bool IsKeyADigit(Key key)
       // {
            //this will allow the user to see the key numbers
           // return (key >= Key.D0 && key <= Key.D9) || 
             //   (key >= Key.NumPad0 && key <= Key.NumPad9);

            //this will show a key number to allow the user the enter the numbers 
            //in the following functions
         //   NumberOfDegree.Show = true;
           // NumberOfHours.Show = true;
            //NumberOfMunites.Show = true;

      //  }


    }
}
