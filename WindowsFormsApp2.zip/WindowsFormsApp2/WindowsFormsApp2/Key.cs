﻿namespace WindowsFormsApp2
{
    public class Key
    {
    }
}